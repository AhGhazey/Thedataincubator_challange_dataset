import flask,flask.views
from bokeh.plotting import figure
from bokeh.resources import CDN
from bokeh import embed
import csv

app = flask.Flask(__name__)
app.secret_key ="AhmedGhazey"
app.debug = True
def read_data ():
    price = []
    sqf = []
    with open('sales_data.csv', 'r') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',',)
        for row in spamreader:
            sqf.append(row[5])
            price.append(row[2])
    
    predictions = []
    for i in range (1,len(sqf)):
        predictions.append(get_price(float(sqf[i])))
        
                    
    return sqf,price,predictions
     
def get_price(area):
    intercept = -47114.0206702 
    slope = 281.957850166 
    estimated_price = intercept+(slope*area)
    return estimated_price



class View(flask.views.MethodView):
    def get(self):
        sqf,price,predictions = read_data()
        sqf = sqf[1:]
        price = price[1:]
        p = figure(title='Sales data model',plot_width=500,plot_height=400)
        # add the line
        p.xaxis.axis_label = "square feet"
        p.yaxis.axis_label = "price"
#         p.multi_line([sqf,price],[sqf,predictions],color=["firebrick", "navy"], alpha=[0.8, 0.3], line_width=3)
        p.line(sqf,predictions)
        script,div = embed.components(p)
        
        
        p2 = figure(title='Sales data',plot_width=500,plot_height=400)
        # add the line
        p2.xaxis.axis_label = "square feet"
        p2.yaxis.axis_label = "price"
        p2.line(sqf,price)
        script2,div2 = embed.components(p2)
        
        return flask.render_template('index.html',gscript=script,gdiv=div, sscript = script2,sdiv = div2)
    
    def post(self):
        area = flask.request.form['aree_feet']
        area1 = float(area)
        value = get_price(area1)
        flask.flash(value)
        return self.get()
app.add_url_rule('/', view_func=View.as_view('main'), methods=['GET','POST'])


app.run()